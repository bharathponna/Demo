package com.konnectco.tests;

public class HomePage {

}
