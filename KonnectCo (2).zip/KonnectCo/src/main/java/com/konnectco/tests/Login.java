package com.konnectco.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.konnectco.utilities.GetElementIdentifier;
import com.konnectco.utilities.TestRunner;
import com.konnectco.utilities.ReadTestExcel;
import com.konnectco.utilities.ElementOperation;

public class Login extends TestRunner{

	static GetElementIdentifier gei;
	static String curr_app="loginpage";
	static WebDriverWait wait;
	static String userName;
	static String userEmail;

	static ElementOperation eo;

	public void launch() throws Exception
	{
		eo=new ElementOperation();
		System.setProperty("webdriver.chrome.driver", "./WebDriver/chromedriver.exe");
		driver=new ChromeDriver();
		gei=new GetElementIdentifier();
		String url=null;
		try {
			url=gei.getConfig("url");

		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get url from datasheet "+e.getMessage());
			throw new Exception("Failed to get url from datasheet "+e.getMessage());
		}

		try {
			driver.get(url);
			extentTest.info("Launched <b>"+url+ "</b> URL");
			driver.manage().window().maximize();
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to launch url "+e.getMessage());
			throw new Exception("Failed to launch url "+e.getMessage());
		}


		if(driver.findElements(By.xpath(gei.getProperty("konnectcoLogo",curr_app))).size()>=1)
		{
			extentTest.info("Successfully Navigate to Login Page and Validated <b>KonnectCo Logo</b> is disaplyed");
		}
		else
		{
			extentTest.log(Status.FAIL, "Failed to navigate to the  Login Page");
			throw new Exception("Failed to navigate to the  Login Page");
		}

	}

	public void verifyValidLoginToKonnectCo() throws Exception
	{
		launch();
		wait=new WebDriverWait(driver, 15);
		String password=null;

		try {
			//userEmail=readTestExcel.getTestData(dataSheetRow, "$UserName");
			userEmail=gei.getConfig("userEmail");
			eo.enterText(driver, "xpath", "userNameTextFeild", userEmail, curr_app);
			extentTest.info("Entered email in user name text field "+userEmail);
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Failed to enter user email in user name text field "+e.getMessage());
			throw new Exception("Failed to enter user email in user name text field "+e.getMessage());
		}

		try {
			eo.clickElement(driver, "xpath", "nextButton", curr_app);
			extentTest.info("Successfully clicked on <b> NextButton </b>");
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Failed to click on Next button "+e.getMessage());
			throw new Exception("Failed to click on Next button  "+e.getMessage() );
		}

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("LoginButton",curr_app))));
			extentTest.info("Successfully validated that <b> Login Button </b> is displayed");
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Could not locate Login Button "+e.getMessage());
			throw new Exception("Could not locate Login Button  "+e.getMessage() );
		}

		try {
			password=gei.getConfig("password");
			eo.enterText(driver, "xpath", "passwordTextFeild", password, curr_app);
			extentTest.info("Entered password **********");
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Failed to enter user password in password text field "+e.getMessage());
			throw new Exception("Failed to enter user password in password text field  "+e.getMessage() );
		}

		Thread.sleep(3000);

		try {
			eo.clickElement(driver, "xpath", "LoginButton", curr_app);
			extentTest.info("Successfully clicked on <b> Login Button </b>");
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Failed to click on Login Button "+e.getMessage());
			throw new Exception("Failed to click on Login Button  "+e.getMessage() );
		}

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("logoHomePage",curr_app))));
			extentTest.info("Successfully navigated to Home Page and validated that <b> Freyr Org Logo </b> is displayed");
		}catch(Exception e) {
			extentTest.log(Status.FAIL, "Failed to validate Freyr logo on Home Page "+e.getMessage());
			throw new Exception("Failed to validate Freyr logo on Home Page  "+e.getMessage() );
		}

		try {
			eo.clickElement(driver, "xpath", "profileIcon", curr_app);
			String tempUserEmail=eo.getText(driver, "xpath", "userEmail", curr_app).trim();
			if(userEmail.trim().equalsIgnoreCase(tempUserEmail))
			{
				extentTest.info("User email from the profile menu matches with the expected email <b>"+userEmail+"</b>");
			}
			else
			{
				extentTest.log(Status.FAIL, "Expected User email : "+userEmail+" does not match with Actual email :"+tempUserEmail);
				throw new Exception("Expected User email : "+userEmail+" does not match with Actual email :"+tempUserEmail);
			}
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to navigate to Home Page "+e.getMessage());
			throw new Exception("Failed to navigate to Home Page "+e.getMessage());
		}

	}

	public void verifyInvalidLoginToKonnectco() throws Exception
	{

		boolean flag=false;
		String password=null;
		String errorMessage;
		launch();
		wait=new WebDriverWait(driver, 1);
		try {
			userEmail=userEmail=gei.getConfig("userEmail");
			password=userEmail=gei.getConfig("password");
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get username/password from datasheet "+e.getMessage());
			throw new Exception("Failed to get username/password from datasheet "+e.getMessage());
		}
		try {
			eo.enterText(driver, "xpath", "userNameTextFeild", userEmail, curr_app);
			extentTest.info("Entered user name"+userEmail);
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to enter username "+e.getMessage());
			throw new Exception("Failed to enter username "+e.getMessage());
		}
		try {
			eo.clickElement(driver, "xpath", "nextButton", curr_app);
			extentTest.info("Successfully clicked on <b>Next Button</b>");
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to click on Next Button "+e.getMessage());
			throw new Exception("Failed to click on Next Button "+e.getMessage());
		}

		try {
			flag=eo.isDisplayed(driver, "xpath", "emailError", curr_app);
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to check if errormessage is displayed "+e.getMessage());
			throw new Exception("Failed to check if errormessage is displayed "+e.getMessage());
		}

		if(flag)
		{
			errorMessage=eo.getText(driver, "xpath", "emailError", curr_app);
			extentTest.info("Successfully validated invliad user name error "+errorMessage);
		}
		else
		{
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("LoginButton",curr_app))));

			try {
				eo.enterText(driver, "xpath", "passwordTextFeild", password, curr_app);
				extentTest.info("Entered password *********");
			}catch(Exception e)
			{
				extentTest.log(Status.FAIL, "Failed to enter the password in password field "+e.getMessage());
				throw new Exception("Failed to enter the password in password field "+e.getMessage());
			}
			try {
				eo.clickElement(driver, "xpath", "LoginButton", curr_app);
				extentTest.info("Successfully clicked on NextButton");
			}catch(Exception e){
				extentTest.log(Status.FAIL, "Failed to click on next button "+e.getMessage());
				throw new Exception("Failed to click on next button "+e.getMessage());
			}
			try {
				flag=eo.isDisplayed(driver, "xpath", "emailError", curr_app);
			}
			catch(Exception e){
				extentTest.log(Status.FAIL, "Failed to check if errormessage is displayed "+e.getMessage());
				throw new Exception("Failed to check if errormessage is displayed "+e.getMessage());
			}
			if(flag)
			{
				errorMessage=eo.getText(driver, "xpath", "emailError", curr_app);
				extentTest.info("Successfully validated invliad user name error "+errorMessage);
			}
			else{
				extentTest.log(Status.FAIL, "Failed to validate the error message for invalid password");
				throw new Exception("Failed to validate the error message for invalid password");
			}
		}
	}

	public void getUserName() throws Exception
	{
		try {
			userName=driver.findElement(By.xpath(gei.getProperty("userName", curr_app))).getText();
			extentTest.info("Logged in KonnectCo user Name is <b>"+userName+"</b>");
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get the KonnectCo user name");
		}

	}

	public void post() throws Exception
	{
		wait=new WebDriverWait(driver, 5);
		driver.findElement(By.xpath(gei.getProperty("postTab", curr_app))).click();
		extentTest.info("Clicked on Post Message tab");
		String textToPost=readTestExcel.getTestData(dataSheetRow, "$Message")+time;
		driver.findElement(By.xpath(gei.getProperty("postMessageTextBox",curr_app))).sendKeys(textToPost);
		extentTest.info("Entered Text in post text area: "+textToPost);

		driver.findElement(By.xpath(gei.getProperty("postButton", curr_app))).click();
		extentTest.info("Successfully clicked on post message");
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("textPosted",curr_app))));
			eo.javaScriptScrollToViewElement(driver, driver.findElement(By.xpath(gei.getProperty("textPosted", curr_app))), curr_app);
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to scroll to the posted message");
			throw new Exception("Failed to scroll to the posted message");
		}
		if(driver.findElement(By.xpath(gei.getProperty("textPosted", curr_app))).getText().equals(textToPost))
		{
			extentTest.info("validated the posted message successfully");
		}
		else
		{
			extentTest.log(Status.FAIL, "Failed to validate the message posted");
			throw new Exception("Failed to validate the message posted");
		}		
	}

	public void postAppreciation() throws Exception
	{

		driver.findElement(By.xpath(gei.getProperty("appreciationTab", curr_app))).click();
		extentTest.info("Clicked on appreciation Message tab");
		String firstName=readTestExcel.getTestData(dataSheetRow, "$FirstName");
		String lastName=readTestExcel.getTestData(dataSheetRow, "$LastName");
		driver.findElement(By.xpath(gei.getProperty("appreciateWho", curr_app))).click();
		driver.findElement(By.xpath(gei.getProperty("appreciateWho", curr_app))).sendKeys(firstName);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("employeeNameList",curr_app).replace("{firstName}", firstName))));
			driver.findElement(By.xpath(gei.getProperty("employeeNameList",curr_app).replace("{firstName}", firstName))).click();

		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get user from suggestions list");
			throw new Exception("Faied to get the user from suggestions list");
		}

		String appreciationDesc=readTestExcel.getTestData(dataSheetRow, "$AppreciationDesc")+" "+time;
		driver.findElement(By.xpath(gei.getProperty("describeAppreciation",curr_app))).sendKeys(appreciationDesc);
		String appreciationType=readTestExcel.getTestData(dataSheetRow, "$AppreciationType");
		driver.findElement(By.xpath(gei.getProperty("appreciationType", curr_app).replace("{apptype}", appreciationType))).click();

		driver.findElement(By.xpath(gei.getProperty("appreciateButton", curr_app))).click();

		try {
			//eo.javaScriptScrollToViewElement(driver, driver.findElement(By.xpath(gei.getProperty("postedAppreciation", curr_app).replace("{appType}", appreciationType))));
			if(driver.findElement(By.xpath(gei.getProperty("postedAppreciation", curr_app).replace("{appType}", appreciationType))).isDisplayed())
			{
				extentTest.info(appreciationType+" Appriciation Posted successfully ");
			}
			else
			{
				extentTest.log(Status.FAIL, "Failed to validate the posted <b>"+appreciationType+" </b>appreciation");
				throw new Exception("Failed to validate the appreciation");
			}
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to scroll to the posted message");
			throw new Exception("Failed to scroll to the posted message");
		}

	}



}
