package com.konnectco.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class GetElementIdentifier {
	
	public String getProperty(String key,String module) throws Exception
	{
		String locator=null;
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/ElementIdentifiers/"+module+".properties"));
		
		Properties prop = new Properties();
		prop.load(fis);
		locator=prop.getProperty(key);
		return locator;
	}
	
	public String getConfig(String key) throws Exception
	{
		String value=null;
		FileInputStream fis = new FileInputStream(new File("./configurations/configurations.properties"));
		Properties prop = new Properties();
		prop.load(fis);
		value=prop.getProperty(key);
		return value;
	}

}
