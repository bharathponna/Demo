package com.konnectco.utilities;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class TestRunner {

	public static String keywordName;

	public static String type;
	public static String action;
	public static String key;
	public static String value;
	public static String JSONFile;
	public static String testCaseID;
	public static String dataSheetName;
	public static int testDataRowcount;
	public static boolean resultFlag;
	public static int dataSheetRow;
	public static ReadTestExcel readTestExcel;
	public static ElementOperation WebAction;
	public static String time;

	public static List<String> enabledTests;

	public static ExtentHtmlReporter htmlReporter;
	public static ExtentReports extent;
	public static ExtentTest extentTest;

	public static WebDriver driver;

	@Test
	public void KDTRun() throws Exception
	{
		readTestExcel=new ReadTestExcel();
		WebAction =new ElementOperation();
		Date date=new Date();
		SimpleDateFormat Dateformat=new SimpleDateFormat("ddMMMYYYHHmmssSSS");
		time=Dateformat.format(date).toString();
		htmlReporter = new ExtentHtmlReporter("./TestReports/Report"+time+".html");
		htmlReporter.config().setDocumentTitle("KonnectCo Automation Report");
		htmlReporter.config().setReportName("Automation Report "+time);
		extent =new ExtentReports();
		extent.attachReporter(htmlReporter);
		String[] keywordList;
		readTestExcel.readTestExcel();
		readTestExcel.tests();
		for(String s:enabledTests)
		{
			testCaseID=s;
			readTestExcel.setDataSheet();
			extentTest=extent.createTest(testCaseID);
			for(int i=1; i<testDataRowcount;i++)
			{
				dataSheetRow=i;
				keywordName=readTestExcel.getTestData(i,"Keywords");
				keywordList=keywordName.split(",");
				for(String key:keywordList)
				{
					try {
						String classname="com.konnectco.tests."+key.split("[.]")[0];
						String testName=key.split("[.]")[1];
						Class<?> c= Class.forName(classname);
						Object b=c.newInstance();
						Method method=c.getMethod(testName);
						method.setAccessible(true);
						method.invoke(b);
						extentTest.info("Executing Keyword "+classname+" and test "+testName);
					}
					catch(Exception e)
					{
						extentTest.fail("Failed to complete keyword execution ");
						driver.quit();
					}
				}
				driver.quit();
			}
		}
		extent.flush();
	}
}
