package com.konnectco.keywords;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.Status;
import com.konnectco.utilities.GetElementIdentifiers;
import com.konnectco.utilities.ReadTestExcel;
import com.konnectco.utilities.WebActions;

public class Common extends KDTDriver{

	static GetElementIdentifiers gei;
	static String curr_app="loginpage";
	static WebDriverWait wait;
	static String userName;
	static String userEmail;

	static WebActions webaction;

	public void launch() throws Exception
	{
		webaction=new WebActions();
		System.setProperty("webdriver.chrome.driver", "./WebDriver/chromedriver.exe");
		driver=new ChromeDriver();
		gei=new GetElementIdentifiers();
		String url=readTestExcel.getTestData(dataSheetRow,"$url");
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5000, TimeUnit.MILLISECONDS);
		if(driver.findElements(By.xpath(gei.getProperty("konnectcoLogo",curr_app))).size()>=1)
		{
			extentTest.info("Validate KonnectCo Logo - Success	");
			extentTest.info("Successfully Navigate to Login Page");
		}
		else
		{
			extentTest.log(Status.FAIL, "Failed to Load Login Page");
			throw new Exception("Failed to load login page");

		}

	}

	public void login() throws Exception
	{
		wait=new WebDriverWait(driver, 15);
		userEmail=readTestExcel.getTestData(dataSheetRow, "$UserName");
		driver.findElement(By.xpath(gei.getProperty("userNameTextFeild",curr_app))).sendKeys(userEmail);
		extentTest.info("Entered user name"+userEmail);
		driver.findElement(By.xpath(gei.getProperty("nextButton",curr_app))).click();


		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("LoginButton",curr_app))));


		driver.findElement(By.xpath(gei.getProperty("passwordTextFeild",curr_app))).sendKeys(readTestExcel.getTestData(dataSheetRow,"$Password"));
		extentTest.info("Entered password *********");
		Thread.sleep(3000);
		driver.findElement(By.xpath(gei.getProperty("LoginButton",curr_app))).click();
		extentTest.info("Clicked on NextButton");

		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("logoHomePage",curr_app))));
			extentTest.info("Validate Freyr Org Log - Success");
			extentTest.info("Successfully navigated to Home Page");
			driver.findElement(By.xpath(gei.getProperty("profileIcon", curr_app))).click();
			if(userEmail.trim().equalsIgnoreCase(driver.findElement(By.xpath(gei.getProperty("userEmail", curr_app))).getText().trim()))
			{
				extentTest.info("User email from the profile menu matches with the expected email <b>"+userEmail+"</b>");
			}
			else
			{
				extentTest.log(Status.FAIL, "User email does not match Expected : "+userEmail+" Actual email is :"+driver.findElement(By.xpath(gei.getProperty("userEmail", curr_app))).getText().trim());
				throw new Exception("Failed to navigate to Home Page");
			}
		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to navigate to Home Page "+e.getMessage());
			throw new Exception("Failed to navigate to Home Page "+e.getMessage());
		}

	}

	public void validateInvalidLogin() throws Exception
	{

		wait=new WebDriverWait(driver, 1);
		String username=readTestExcel.getTestData(dataSheetRow,"$UserName");
		driver.findElement(By.xpath(gei.getProperty("userNameTextFeild",curr_app))).sendKeys(username);
		extentTest.info("Entered user name"+username);
		driver.findElement(By.xpath(gei.getProperty("nextButton",curr_app))).click();
		boolean flag=false;
		try {
			flag=driver.findElement(By.xpath(gei.getProperty("emailError",curr_app))).isDisplayed();
		}
		catch(Exception e)
		{

		}

		if(flag)
		{
			extentTest.info("Validate user name error message is displayed - Successful");
		}
		else
		{
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("LoginButton",curr_app))));
			driver.findElement(By.xpath(gei.getProperty("passwordTextFeild",curr_app))).sendKeys(readTestExcel.getTestData(dataSheetRow,"$Password"));
			extentTest.info("Entered password *********");
			driver.findElement(By.xpath(gei.getProperty("LoginButton",curr_app))).click();
			extentTest.info("Clicked on NextButton");
			try {
				flag=driver.findElement(By.xpath(gei.getProperty("passwordError",curr_app))).isDisplayed();
			}
			catch(Exception e)
			{
				if(flag)
				{
					extentTest.info("Invalid Password - Error message is displayed");
				}
				else
				{
					extentTest.log(Status.FAIL, "Failed to validate the error message");
				}
			}


		}

	}

	public void getUserName() throws Exception
	{
		try {
			userName=driver.findElement(By.xpath(gei.getProperty("userName", curr_app))).getText();
			extentTest.info("Logged in KonnectCo user Name is <b>"+userName+"</b>");
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get the KonnectCo user name");
		}

	}

	public void post() throws Exception
	{
		wait=new WebDriverWait(driver, 5);
		driver.findElement(By.xpath(gei.getProperty("postTab", curr_app))).click();
		extentTest.info("Clicked on Post Message tab");
		String textToPost=readTestExcel.getTestData(dataSheetRow, "$Message")+time;
		driver.findElement(By.xpath(gei.getProperty("postMessageTextBox",curr_app))).sendKeys(textToPost);
		extentTest.info("Entered Text in post text area: "+textToPost);

		driver.findElement(By.xpath(gei.getProperty("postButton", curr_app))).click();
		extentTest.info("Successfully clicked on post message");
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("textPosted",curr_app))));
			WebAction.javaScriptScrollToViewElement(driver, driver.findElement(By.xpath(gei.getProperty("textPosted", curr_app))));
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to scroll to the posted message");
			throw new Exception("Failed to scroll to the posted message");
		}
		if(driver.findElement(By.xpath(gei.getProperty("textPosted", curr_app))).getText().equals(textToPost))
		{
			extentTest.info("validated the posted message successfully");
		}
		else
		{
			extentTest.log(Status.FAIL, "Failed to validate the message posted");
			throw new Exception("Failed to validate the message posted");
		}		
	}

	public void postAppreciation() throws Exception
	{
		
		driver.findElement(By.xpath(gei.getProperty("appreciationTab", curr_app))).click();
		extentTest.info("Clicked on appreciation Message tab");
		String firstName=readTestExcel.getTestData(dataSheetRow, "$FirstName");
		String lastName=readTestExcel.getTestData(dataSheetRow, "$LastName");
		driver.findElement(By.xpath(gei.getProperty("appreciateWho", curr_app))).click();
		driver.findElement(By.xpath(gei.getProperty("appreciateWho", curr_app))).sendKeys(firstName);
		try {
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(gei.getProperty("employeeNameList",curr_app).replace("{firstName}", firstName))));
			driver.findElement(By.xpath(gei.getProperty("employeeNameList",curr_app).replace("{firstName}", firstName))).click();

		}catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to get user from suggestions list");
			throw new Exception("Faied to get the user from suggestions list");
		}

		String appreciationDesc=readTestExcel.getTestData(dataSheetRow, "$AppreciationDesc")+" "+time;
 		driver.findElement(By.xpath(gei.getProperty("describeAppreciation",curr_app))).sendKeys(appreciationDesc);
		String appreciationType=readTestExcel.getTestData(dataSheetRow, "$AppreciationType");
		driver.findElement(By.xpath(gei.getProperty("appreciationType", curr_app).replace("{apptype}", appreciationType))).click();

		driver.findElement(By.xpath(gei.getProperty("appreciateButton", curr_app))).click();

		try {
			WebAction.javaScriptScrollToViewElement(driver, driver.findElement(By.xpath(gei.getProperty("postedAppreciation", curr_app).replace("{appType}", appreciationType))));
			if(driver.findElement(By.xpath(gei.getProperty("postedAppreciation", curr_app).replace("{appType}", appreciationType))).isDisplayed())
			{
				extentTest.info(appreciationType+" Appriciation Posted successfully ");
			}
			else
			{
				extentTest.log(Status.FAIL, "Failed to validate the posted <b>"+appreciationType+" </b>appreciation");
				throw new Exception("Failed to validate the appreciation");
			}
		}
		catch(Exception e)
		{
			extentTest.log(Status.FAIL, "Failed to scroll to the posted message");
			throw new Exception("Failed to scroll to the posted message");
		}

	}



}
