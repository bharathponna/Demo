package com.konnectco.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class GetElementIdentifiers {
	
	public String getProperty(String key,String module) throws Exception
	{
		String locator=null;
		FileInputStream fis = new FileInputStream(new File("./src/main/resources/ElementIdentifiers/"+module+".properties"));
		
		Properties prop = new Properties();
		prop.load(fis);
		locator=prop.getProperty(key);
		return locator;
	}

}
