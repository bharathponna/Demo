package com.konnectco.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import java.lang.reflect.Method;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.konnectco.keywords.KDTDriver;

public class ReadTestExcel extends KDTDriver
{

	static Sheet dataSheet;
	static String testCaseName;
	static Sheet TestCase;
	static int testIDRowIndex;

	static Workbook wb;
	static Workbook writetoexcel;

	static File ExcelFile;
	static String keywordName;
	static String testKeyword;
	static String testDesc;
	static int successColNum;
	//static String dataSheetName;
	static int dateColNum;

	public static void writeOutcome(int k) throws Exception
	{
		String path=ExcelFile.getAbsolutePath();
		successColNum=getColNumber(dataSheet,"$Pass/Fail?");
		dateColNum=getColNumber(dataSheet, "$ExecutionDate");

		FileInputStream is=new FileInputStream(new File(path));

		writetoexcel=new XSSFWorkbook(is); 
		Cell cell = null;

		String testResult=KDTDriver.resultFlag?"Pass":"Fail";

		Sheet testsheet = writetoexcel.getSheet(dataSheetName.replace("::", ""));
		Row sheetrow = testsheet.getRow(k);
		if(sheetrow == null){
			sheetrow = testsheet.createRow(k);
		} 
		System.out.println(testsheet.getRow(k).getCell(successColNum).toString());

		cell = testsheet.getRow(k).getCell(successColNum);
		cell = testsheet.getRow(k).createCell(successColNum);		 
		cell.setCellValue(testResult);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        cell = testsheet.getRow(k).getCell(dateColNum);
        cell = testsheet.getRow(k).createCell(dateColNum);    
        cell.setCellValue(dtf.format(now));
         System.out.println(dtf.format(now));
         
		is.close();
		FileOutputStream outFile =new FileOutputStream(new File(path));
		writetoexcel.write(outFile);
		outFile.close();
	}

	public static int getColNumber(Sheet sheet,String Value) {
		Row row;
		int count=0;
		row=sheet.getRow(0);
		for(Cell cell : row)
		{	
			if(cell.getStringCellValue().equals(Value))
			{
				testIDRowIndex=cell.getRowIndex();
				break;
			}
			count++;
		}
		return count;
	}

	public static String getKeyword()
	{
		int keycolmn;
		keycolmn=getColNumber(TestCase, "Keyword_Name");
		testKeyword=TestCase.getRow(getRowIndex(TestCase,testCaseName)).getCell(keycolmn).toString();
		return testKeyword;		
	}

	public static String getTestDesc()
	{
		int keycolmn;
		keycolmn=getColNumber(TestCase, "Test_Case_Scenario");
		testDesc=TestCase.getRow(getRowIndex(TestCase,testCaseName)).getCell(keycolmn).toString();
		return testDesc;
	}

	public static String getApplicationName()
	{
		int keycolmn;
		String applicationName;
		keycolmn=getColNumber(TestCase, "Application_Name");
		try {
			applicationName=TestCase.getRow(getRowIndex(TestCase,testCaseID)).getCell(keycolmn).toString();
		}
		catch(IllegalStateException e)
		{
			applicationName=String.valueOf(TestCase.getRow(getRowIndex(TestCase,testCaseID)).getCell(keycolmn).getNumericCellValue());

		}
		return applicationName;
	}	

	public static int getRowIndex(Sheet sheet,String Value) {
		Row row;
		int count=0;
		int index=0;
		String cellData="";
		boolean flag=false;
		for(int i=0;i<=sheet.getLastRowNum();i++)
		{
			row=sheet.getRow(count);
			for(Cell cell:row)
			{
				try {
					cellData=cell.getStringCellValue().toString();
				}
				catch(IllegalStateException e)
				{
					cellData=String.valueOf(cell.getNumericCellValue());

				}
				if(cellData.equals(Value))
				{
					flag=true;
					index=cell.getRowIndex();
					break;
				}
			}
			if(flag) {break;}
			else {
				count=count+1;
			}
		}
		return index;
	}

	public static List<String> getenabledtests(Sheet sheet1, int colnum, int rowCount)
	{
		List<String> enabledtcs=new ArrayList<String>();
		for(int i=1;i<=rowCount;i++)
		{
			if((sheet1.getRow(i).getCell(colnum).toString()).equals("Yes"))
			{
				enabledtcs.add(sheet1.getRow(i).getCell(colnum+1).toString());
			}
		}
		return enabledtcs;
	}

	public String getTestData(int rownumber,String Value){

		int colnum;
		String tdata="";
		Row row;
		int count=0;
		row=dataSheet.getRow(0);
		for(Cell cell : row)
		{
			if(cell.getStringCellValue().replace("$", "").equals(Value.replace("$", "")))
			{
				break;
			}
			count++;
		}
		colnum=count;
		tdata=dataSheet.getRow(rownumber).getCell(colnum).toString();
		return tdata;
	}

	public static String getTestData(String Value)
	{
		int colnum;
		int rowCount=1;
		String tdata="";
		Row row;
		int count=0;
		row=dataSheet.getRow(0);
		for(Cell cell : row)
		{
			if(cell.getStringCellValue().replace("$", "").equals(Value.replace("$", "")))
			{
				break;
			}
			count++;
		}
		colnum=count;

		for(int i=1;i<=rowCount;i++)
		{
			tdata=dataSheet.getRow(rowCount).getCell(colnum).toString();
		}
		return tdata;
	}

	private static int getRowCount(Sheet sheet) {
		String data;
		int rowcount=0;
		try {
			Iterator rowIter = sheet.rowIterator();
			Row r = (Row)rowIter.next();
			short lastCellNum = r.getLastCellNum();
			int[] dataCount = new int[lastCellNum];
			int col = 0;
			rowIter = sheet.rowIterator();
			while(rowIter.hasNext()) {
				Iterator cellIter = ((Row)rowIter.next()).cellIterator();
				while(cellIter.hasNext()) {
					Cell cell = (Cell)cellIter.next();
					col = cell.getColumnIndex();
					dataCount[col] += 1;
					DataFormatter df = new DataFormatter();
					data = df.formatCellValue(cell);
					//System.out.println("Data: " + data);
				}
			}
			for(int x = 0; x < dataCount.length; x++) {
				//System.out.println("col " + x + ": " + dataCount[x]);
			}
			rowcount=dataCount[0];
		}
		catch(Exception e) {
			e.printStackTrace();
			//return;
		}
		return rowcount;
	}

	public static void setDataSheet()
	{
		int colnum=getColNumber(TestCase,"DataSheet");
		try {
			dataSheetName=TestCase.getRow(getRowIndex(TestCase,testCaseID)).getCell(colnum).toString();
		}
		catch(Exception e)
		{
			dataSheetName=String.valueOf(TestCase.getRow(getRowIndex(TestCase,testCaseID)).getCell(colnum).getNumericCellValue());
		}
		dataSheet=wb.getSheet(dataSheetName.replace("::", ""));
		//testDataRowcount=dataSheet.getLastRowNum()-dataSheet.getFirstRowNum();
		testDataRowcount=getRowCount(dataSheet);
	}

	public static void readTestExcel() throws IOException, Exception
	{
		File[] files;
		LinkedList<String> paths = new LinkedList<String>();
		enabledTests=new ArrayList<String>();
		JFrame window = new JFrame("KDT File Dialog");
		window.setVisible(true);
		JFileChooser FC = new JFileChooser(System.getProperty("user.dir"));
		FC.setMultiSelectionEnabled(true);
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Excel & CSV files", "xls", "xlsx", "csv");
		FC.setFileFilter(filter);
		int result = FC.showOpenDialog(window);
		window.dispose();
		if (result == JFileChooser.APPROVE_OPTION) {
			files = FC.getSelectedFiles();
		} else {
			files = new File[0];
		}
		ExcelFile=files[0];
		paths.add(ExcelFile.getAbsolutePath());
	}

	public static void tests() throws Exception
	{
		try {
			FileInputStream inputStream = new FileInputStream(ExcelFile);
			wb=new XSSFWorkbook(inputStream);
			TestCase = wb.getSheet("TestCases");
			int rowCount = TestCase.getLastRowNum()-TestCase.getFirstRowNum();
			int colnum=getColNumber(TestCase,"EnableForExecution"); 
			enabledTests=getenabledtests(TestCase,colnum,rowCount);
		} catch (FileNotFoundException e) {
			System.out.println("Error loading the file");
		}		
	}
}