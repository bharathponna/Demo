package com.konnectco.utilities;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.konnectco.keywords.KDTDriver;


public class WebActions extends KDTDriver {

	public static String featureName;
	WebDriver driver;

	Actions act ;

	public void launchBrowser(String browser)
	{
		if(browser.toLowerCase().contains("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "./WebDriver/chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(browser.toLowerCase().contains("ie")||browser.toLowerCase().contains("internet explorer"))
		{
			System.setProperty("webdriver.ie.driver", "./WebDrivers/IEDriverServer.exe");
			driver=new InternetExplorerDriver();
		}
		else if(browser.toLowerCase().contains("firefox"))
		{
			System.setProperty("webdriver.gecko.driver", "./WebDrivers/geckodriver.exe");
			driver=new FirefoxDriver();
		}	
		System.out.println("Successfully launched browser "+browser);
		driver.manage().window().maximize();		
	}

	public void getURL(String URL)
	{
		driver.get(URL);
		System.out.println("Successfully launched url "+URL);
	}

	public void quit()
	{
		driver.quit();
		System.out.println("Successfully closed the driver ");
	}

	public By getWebElementByLocator(WebDriver driver, String locator, String elementIdentifier) throws Exception {
		By ele = null;
		switch (locator.toLowerCase()) {
		case "classname":
			ele = By.className(elementIdentifier);
			break;
		case "cssselector":
			ele = By.cssSelector(elementIdentifier);
			break;
		case "id":
			ele = By.id(elementIdentifier);
			break;
		case "linkText":
			ele = By.linkText(elementIdentifier);
			break;
		case "name":
			ele = By.name(elementIdentifier);
			break;
		case "partiallinktext":
			ele = By.partialLinkText(elementIdentifier);
			break;
		case "tagname":
			ele = By.tagName(elementIdentifier);
			break;
		case "xpath":
			ele = By.xpath(elementIdentifier);
			break;
		default: throw new Exception("There is no Locator with the name - <b>" + locator + "</b>, please specify proper locator");
		}
		try{
			(new WebDriverWait(driver, 60)).until(ExpectedConditions.visibilityOfElementLocated(ele));
		}catch(Exception e){
			throw new Exception("Not able to find web element with locator - <b>" + locator + " = " + 
					elementIdentifier + "</b> after 60 seconds of wait on the web page");
		}
		return ele;
	}

	public void wait(int time){
		try {
			Thread.sleep(time * 1000);
		} catch (InterruptedException e) {
			System.out.println("Time Exceeded for: "+time * 1000+" seconds");
		}
	}	

	public void wait(String seconds)
	{
		int time = Integer.parseInt(seconds);
		try {
			Thread.sleep(time * 1000);
		} catch (InterruptedException e) {
			System.out.println("Time Exceeded for: "+time * 1000+" seconds");
		}
	}

	public void click() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));
		try 
		{			
			String temptext="";
			try {
				temptext=(driver.findElement(ele).getText().length()>1)?driver.findElement(ele).getText():"null";
				System.out.println("Clicked on: "+temptext);
			}
			catch(Exception e){
				System.out.println("Could not click");
			}
			driver.findElement(ele).click();
			System.out.println("Successfully clicked on: "+temptext);
		} catch (Exception e) {
			throw new Exception("Not able to click on an element having " + type + " - <b>" + key + "</b>", e);
		}
	}

	public void enterText(String text) throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));
		try {
			driver.findElement(ele).clear();
			driver.findElement(ele).sendKeys(text);
			System.out.println("Successfully entered text: "+text+" "+driver.findElement(ele).getAttribute("name"));
		} catch (Exception e) {
			throw new Exception("Not able to enter text to the element having " + type + " - <b>" + key + "</b>", e);
		}
	}

	public void getText(String text) throws Exception
	{
		String elementtext="";
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));
		System.out.println("Actual text is: "+text);
		try {
			elementtext=driver.findElement(ele).getText();
			System.out.println("Expected text is: "+elementtext);
		} catch (Exception e) {
			throw new Exception("Not able to click on an element having " + type + " - <b>" + key + "</b>", e);
		}
		if(elementtext.toLowerCase().equals(text.toLowerCase()))
		{
			System.out.println("text displayed is as expected: \""+text+"\"");
		}else
		{
			throw new Exception("text displayed does not match. \""+text+"\" with \""+elementtext+"\"");
		}
	}

	public void hover() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));
		try {
			act=new Actions(driver);
			WebElement ele1=driver.findElement(ele);
			act.moveToElement(ele1).build().perform();
			System.out.println("Succesfully hovered on: "+ele1);			
		} catch (Exception e) {
			throw new Exception("Unable to hover", e);
		}
	}

	public void isVisibleOrNot() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			if(driver.findElement(ele).isDisplayed()) 
			{
				System.out.println("Element is displayed ");
			}
		} catch (Exception e) {
			throw new Exception("Element is not displayed "+e);
		}
	}

	public void selectFromDropdownByVisibleText(String text) throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));		
		try {
			Select dropDown = new Select(driver.findElement(ele));
			dropDown.selectByVisibleText(text);
			System.out.println("Selected "+text+" from the dropdown");
		} catch(Exception e) {
			throw new Exception("Element was not selected from the dropdown "+e);
		}
	}

	public void selectFromDropdownByIndex(String indexVal) throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));		
		try {
			Select dropDown = new Select(driver.findElement(ele));
			dropDown.selectByIndex(Integer.parseInt(indexVal));
			System.out.println("Selected "+indexVal+" option from the dropdown");
		} catch(Exception e) {
			throw new Exception("Element was not selected from the dropdown "+e);
		}
	}

	public void selectFromDropdownByValue(String text) throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.elementToBeClickable(ele));		
		try {
			Select dropDown = new Select(driver.findElement(ele));
			dropDown.selectByValue(text);
			System.out.println("Selected "+text+" from the dropdown");
		} catch(Exception e) {
			throw new Exception("Element was not selected from the dropdown "+e);
		}
	}

	public void scrollToViewElement() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));	
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebElement ele1 = driver.findElement(ele);
		js.executeScript("arguments[0].scrollIntoView();", ele1);
	}

	public void javaScriptRightClickOnElement() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		try{
			String rightClickObj = "var evt = arguments[0].ownerDocument.createEvent('MouseEvents');"
					+"evt.initMouseEvent('contextmenu', true, true,arguments[0].ownerDocument.defaultView, 1, 0, 0, 0, 0, false,"
					+ "false, false, false, 2, null);if (document.createEventObject){return arguments[0].fireEvent('onclick', evt);"
					+ " }else{return !arguments[0].dispatchEvent(evt);}";
			((JavascriptExecutor) driver).executeScript(rightClickObj, driver.findElement(ele));
		}catch(JavascriptException e){
			throw new Exception(", Not able to Right click on the element", e);
		}
	}

	public void javaScriptToScrollDownPage() throws Exception{
		try{
			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight)");
		}catch(Exception e){
			throw new Exception("Not able to scroll down the page", e);
		}
	}

	public void waitForPageload() throws Exception{
		String BrowserStatus=null;
		do {
			wait(1);
			try {
				BrowserStatus = (String) ((JavascriptExecutor) driver).executeScript("return document.readyState;");
			}catch(Exception e){

			}
		} while (!(BrowserStatus.compareToIgnoreCase("complete")==0));
		BrowserStatus = null;
	}

	public void clearData() throws Exception {
		By ele = getWebElementByLocator(driver, type, key);
		try {
			driver.findElement(ele).clear();
		} catch (Exception e) {
			throw new Exception("Not able to clear textbox in an element having xpath - <b>" + key + "</b>", e);
		}
	}

	public boolean isDisplayedOrNot() throws Exception {
		boolean isdisplayed;
		try {
			By ele = getWebElementByLocator(driver, type, key);
			isdisplayed = driver.findElement(ele).isDisplayed();
		} catch (Exception e) {
			isdisplayed=false;
		}
		return isdisplayed;
	}

	public void selectRadioButton() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			if(driver.findElement(ele).isSelected()) {
				System.out.println("Element is selected ");
			}
		} catch (Exception e) {
			throw new Exception("Element is not selected "+e);
		}
	}

	public void deSelectRadioButton() throws Exception 
	{
		By ele = getWebElementByLocator(driver, type, key);
		boolean isSelected;
		try {
			isSelected = driver.findElement(ele).isSelected();
		} catch (Exception e) {
			throw new Exception("Not able to verify whether element is selected or not having xpath - <b>" + ele + "</b>", e);
		}
		if(isSelected){
			try {
				driver.findElement(ele).click();
				System.out.println("Element is selected");
			} catch (Exception e) {
				throw new Exception("Not able to click on an element having xpath - <b>" + ele + "</b>", e);
			}
		}
	}

	public void checkCheckBox() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		boolean isSelected;
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			isSelected = driver.findElement(ele).isSelected();
			System.out.println("Element is selected ");
		} catch (Exception e) {
			throw new Exception("Element is either not selected or not having xpath "+e);
		}
		if(!isSelected){
			try {
				driver.findElement(ele).click();
				System.out.println("Element is checked");
			} catch (Exception e) {
				throw new Exception("Not able to click on an element having xpath - <b>" + ele + "</b>", e);
			}
		}
	}

	public void uncheckCheckBox() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		boolean isSelected;
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			isSelected= driver.findElement(ele).isSelected();
			System.out.println("Element is selected ");
		}
		catch (Exception e) {
			throw new Exception("Element is either not selected or not having xpath "+e);
		}
		if(isSelected){
			try {
				driver.findElement(ele).click();
			} catch (Exception e) {
				throw new Exception("Not able to click on an element having xpath - <b>" + ele + "</b>", e);
			}
		}
	}

	public void isEnabled() throws Exception
	{
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			if(driver.findElement(ele).isEnabled()) {
				System.out.println("Element is enabled ");
			}
		} catch (Exception e) {
			throw new Exception("Element is not enabled "+e);
		}
	}

	public void isSelected() throws Exception {
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			if(driver.findElement(ele).isSelected()) {
				System.out.println("Element is selected ");
			}
		} catch (Exception e) {
			throw new Exception("Not able to verify whether element is selected or not having xpath - <b>" + ele + "</b>", e);
		}
	}

	public void switchToIFrame() throws Exception {
		By ele = getWebElementByLocator(driver, type, key);
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.presenceOfElementLocated(ele));
		try {
			driver.switchTo().defaultContent();
			driver.switchTo().frame(String.valueOf(ele));
		}
		catch(Exception e) {
			throw new Exception("Not able to switch to a different frame - <b>" + ele + "</b>", e);
		}
	}
	
	public void javaScriptScrollToViewElement(WebDriver driver, WebElement element) throws Exception{
		(new WebDriverWait(driver, 60)).until(ExpectedConditions.visibilityOf(element));
		try {
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		} catch (Exception e) {
			throw new Exception("Not able to scroll on an element using javascript</b>", e);
		}
	}
}