package com.konnectco.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class HomePage {
	
	@FindBy(how=How.XPATH,using="//header[@class='logo']/img")
	WebElement konnectCoLogo;
	
	@FindBy(how=How.ID,using="UserName")
	WebElement userNameTextBox;
	
	@FindBy(how=How.ID,using="btnNext")
	WebElement nextButton;
	
	@FindBy(how=How.XPATH,using="//a[text()=\"Forgot password?\"]")
	WebElement forgotPassword;
	
	
	@FindBy(how=How.ID,using="Password1")
	WebElement passwordTextField;
	
	
	@FindBy(how=How.ID,using="btnSave")
	WebElement loginButton;
	



}
